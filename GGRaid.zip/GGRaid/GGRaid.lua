local frame = CreateFrame("Frame")

print("|cffFF69B4[GGRaid]|r Addon loaded successfully!")

local isYelling = false
local isChanneling = false

local yellMessage = "LFM ICC 25 HC"
local chanMessage = "LFM ICC 25 HC"

local yellInterval = 22
local chanInterval = 62

local yellElapsed = 0
local chanElapsed = 0

local chanName = nil
local chanID = nil

local selectedRaid = "ICC"
local selectedSize = "25"
local selectedDifficulty = "HC"
local neededTalents = {} 

local customMsgText = ""
local achRequired = "No"
local minGsText = ""
local reservedText = ""
local achievementLink = ""

local needRoles = { Tanks = false, MDPS = false, RDPS = false, Healers = false }

local pureCustomMode = false
local pureCustomText = ""

local function printMsg(msg)
    print("|cffFF69B4[GGRaid]|r " .. msg)
end

local function NotifyMessageChange()
    local activeMsg = pureCustomMode and pureCustomText or yellMessage
    printMsg("Updated Msg: " .. activeMsg)
end

local function GetJoinedChannelID(channel)
    if not channel or channel == "" then return nil end
    local id = GetChannelName(channel)
    if id ~= 0 then return id end
    return nil
end

local function ReadAchievementFromMacro()
    local macroIndex = GetMacroIndexByName("GGRaidAch")
    if macroIndex and macroIndex > 0 then
        local body = GetMacroBody(macroIndex)
        if body then
            local link = body:match("(|c%x+|Hachievement[^\r\n]-|h%[.-%]|h|r)")
            if link then
                achievementLink = link
                return true
            end
        end
    end
    return false
end

local function CreateSilverButton(parent, width, height, text)
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(width, height)
    
    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(btn)
    bg:SetTexture(0.85, 0.85, 0.85, 0.9)
    btn.bg = bg
    
    local border = btn:CreateTexture(nil, "BORDER")
    border:SetPoint("TOPLEFT", btn, "TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", 1, -1)
    border:SetTexture(0.3, 0.3, 0.3, 1)
    
    local fontStr = btn:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    fontStr:SetPoint("CENTER", btn, "CENTER", 0, 0)
    fontStr:SetTextColor(0.1, 0.1, 0.1, 1)
    fontStr:SetText(text)
    btn.text = fontStr
    
    return btn
end

local function CreateRectEditBox(parent, width, height)
    local eb = CreateFrame("EditBox", nil, parent)
    eb:SetSize(width, height)
    eb:SetAutoFocus(false)
    eb:SetFontObject("GameFontHighlightSmall")
    eb:SetTextInsets(5, 5, 0, 0)
    
    local bg = eb:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(eb)
    bg:SetTexture(0, 0, 0, 1)
    eb.bg = bg
    
    local border = eb:CreateTexture(nil, "BORDER")
    border:SetPoint("TOPLEFT", eb, "TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", eb, "BOTTOMRIGHT", 1, -1)
    border:SetTexture(0.4, 0.4, 0.4, 1)
    
    return eb
end

local function GenerateLFMMessage()
    ReadAchievementFromMacro()

    local maxPlayers = (selectedSize == "10" and 10) or 25
    
    local totalNeeded = 0
    local parts = {}
    
    local roleList = {}
    if needRoles.Tanks then table.insert(roleList, "Tanks") end
    if needRoles.MDPS then table.insert(roleList, "MDPS") end
    if needRoles.RDPS then table.insert(roleList, "RDPS") end
    if needRoles.Healers then table.insert(roleList, "Healers") end
    
    if #roleList > 0 then
        for _, r in ipairs(roleList) do
            table.insert(parts, r)
        end
        for _, count in pairs(neededTalents) do
            if count and count > 0 then totalNeeded = totalNeeded + count end
        end
    else
        local orderedSpecs = {
            -- تانک‌ها (Tanks)
            "Ppala", "Bdk", "Bear", "Prot",
            -- میلی دی‌پی‌اس‌ها (MDPS)
            "Ret", "Crogue", "Assasin", "Sub", "Cat", "Enh", "Fwarr", "Arms", "Unholy", "FDK",
            -- رنج دی‌پی‌اس‌ها (RDPS)
            "Hunter", "MM", "BM", "Surv", "Boomi", "Ele", "SP", "Demo", "Affly", "Destro", "Mage", "Arcane", "Frost", "Fmage",
            -- هیلرها (Healers)
            "Hpala", "Disc", "Holy", "Rshamy", "Rdruid"
        }
        
        for _, talentName in ipairs(orderedSpecs) do
            local count = neededTalents[talentName]
            if count and count > 0 then
                totalNeeded = totalNeeded + count -- محاسبه صحیح تعداد کل برای محاسبات ریاضی رید
                table.insert(parts, talentName)   -- درج فقط یک بار نام اس‌پک در متن پیام
            end
        end
        
        for talentName, count in pairs(neededTalents) do
            if count and count > 0 then
                local found = false
                for _, orderedName in ipairs(orderedSpecs) do
                    if orderedName == talentName then
                        found = true
                        break
                    end
                end
                if not found then
                    totalNeeded = totalNeeded + count
                    table.insert(parts, talentName)
                end
            end
        end
    end
    
    local currentMembers = maxPlayers - totalNeeded
    if currentMembers < 0 then currentMembers = 0 end
    
    local msg = "LFM"
    if selectedRaid ~= "None" then
        msg = msg .. " " .. selectedRaid
    end
    if selectedSize ~= "None" then
        msg = msg .. " " .. selectedSize
    end
    if selectedDifficulty ~= "None" then
        msg = msg .. " " .. selectedDifficulty
    end
    
    if customMsgText ~= "" then
        msg = msg .. " " .. customMsgText
    end
    
    if #parts > 0 then
        msg = msg .. " Need " .. table.concat(parts, " ")
    end
    
    if achRequired == "Yes" then
        msg = msg .. " Req Ach"
    end
    
    if achievementLink ~= "" then
        msg = msg .. " " .. achievementLink
    end
    
    if minGsText ~= "" then
        msg = msg .. " Min GS " .. minGsText
    end
    
    if reservedText ~= "" then
        msg = msg .. " Res " .. reservedText
    end
    
    if selectedSize ~= "None" then
        msg = msg .. " " .. currentMembers .. "/" .. maxPlayers
    end
    
    yellMessage = msg
    chanMessage = msg
end

local function StartYelling()
    ReadAchievementFromMacro()
    GenerateLFMMessage()
    if not isYelling then
        isYelling = true
        yellElapsed = yellInterval
        printMsg("Yell started (" .. yellInterval .. "s).")
    else
        printMsg("Yell already started.")
    end
end

local function StopYelling()
    if isYelling then
        isYelling = false
        printMsg("Yell stopped.")
    else
        printMsg("Yell is not running.")
    end
end

local function StartChanneling()
    ReadAchievementFromMacro()
    GenerateLFMMessage()
    if not chanName then
        printMsg("Error: No channel set. Use /ggraid channel <channel> first.")
        return
    end
    if not isChanneling then
        isChanneling = true
        chanElapsed = chanInterval
        printMsg("Channel messages started on '" .. chanName .. "' (" .. chanInterval .. "s).")
    else
        printMsg("Channel messages already started.")
    end
end

local function StopChanneling()
    if isChanneling then
        isChanneling = false
        printMsg("Channel messages stopped.")
    else
        printMsg("Channel messages are not running.")
    end
end

frame:SetScript("OnUpdate", function(self, elapsed)
    if isYelling then
        yellElapsed = yellElapsed + elapsed
        if yellElapsed >= yellInterval then
            ReadAchievementFromMacro()
            GenerateLFMMessage()
            local finalToSend = pureCustomMode and pureCustomText or yellMessage
            if finalToSend ~= "" then
                SendChatMessage(finalToSend, "YELL")
            end
            yellElapsed = 0
        end
    end
    if isChanneling then
        chanElapsed = chanElapsed + elapsed
        if chanElapsed >= chanInterval then
            ReadAchievementFromMacro()
            GenerateLFMMessage()
            local finalToSend = pureCustomMode and pureCustomText or chanMessage
            if finalToSend ~= "" then
                if chanID then
                    SendChatMessage(finalToSend, "CHANNEL", nil, chanID)
                elseif chanName then
                    local sysChan = { party = "PARTY", raid = "RAID", guild = "GUILD", say = "SAY", yell = "YELL" }
                    local chatType = sysChan[chanName:lower()]
                    if chatType then
                        SendChatMessage(finalToSend, chatType)
                    else
                        isChanneling = false
                        return
                    end
                end
            end
            chanElapsed = 0
        end
    end
end)

local function CreateBuilderUIElements()
    if GGRaidBuilderFrame.initialized then return end
    GGRaidBuilderFrame.initialized = true

    local raids = {"ICC", "RS", "TOC", "VOA", "None"}
    for i, raid in ipairs(raids) do
        local btn = CreateFrame("Button", nil, GGRaidBuilderFrame, "UIPanelButtonTemplate")
        btn:SetSize(65, 22)
        btn:SetPoint("TOPLEFT", 15 + ((i - 1) * 72), -35)
        btn:SetText(raid)
        btn:SetScript("OnClick", function()
            selectedRaid = raid
            GenerateLFMMessage()
            NotifyMessageChange()
        end)
    end

    local sizes = {"10", "25", "None"}
    for i, sSize in ipairs(sizes) do
        local btn = CreateFrame("Button", nil, GGRaidBuilderFrame, "UIPanelButtonTemplate")
        btn:SetSize(60, 22)
        btn:SetPoint("TOPLEFT", 15 + ((i - 1) * 68), -62)
        btn:SetText(sSize)
        btn:SetScript("OnClick", function()
            selectedSize = sSize
            GenerateLFMMessage()
            NotifyMessageChange()
        end)
    end

    local diffs = {"n", "HC", "None"}
    for i, diff in ipairs(diffs) do
        local btn = CreateFrame("Button", nil, GGRaidBuilderFrame, "UIPanelButtonTemplate")
        btn:SetSize(60, 22)
        btn:SetPoint("TOPLEFT", 230 + ((i - 1) * 68), -62)
        btn:SetText(diff)
        btn:SetScript("OnClick", function()
            selectedDifficulty = diff
            GenerateLFMMessage()
            NotifyMessageChange()
        end)
    end

    local talentData = {
        { class = "Paladin", color = "FFF58CBA", specs = { "Ppala", "Hpala", "Ret" } },
        { class = "Priest",  color = "FFFFFFFF", specs = { "Disc", "SP", "Holy" } },
        { class = "Warlock", color = "FF8788EE", specs = { "Demo", "Affly", "Destro" } },
        { class = "Rogue",   color = "FFFFF468", specs = { "Crogue", "Assasin", "Sub" } },
        { class = "Druid",   color = "FFFF7D0A", specs = { "Rdruid", "Cat", "Boomi", "Bear" } },
        { class = "Shaman",  color = "FF0070DE", specs = { "Ele", "Rshamy", "Enh" } },
        { class = "Hunter",  color = "FFABD473", specs = { "MM", "BM", "Surv" } },
        { class = "Warrior", color = "FFC79C6E", specs = { "Fwarr", "Arms", "Prot" } },
        { class = "DK",      color = "FFC41F3B", specs = { "Bdk", "Unholy", "FDK" } },
        { class = "Mage",    color = "FF69CCF0", specs = { "Fmage", "Arcane", "Frost" } }
    }

    local countButtons = {}
    local startY = -92

    for _, row in ipairs(talentData) do
        local cBtn = CreateSilverButton(GGRaidBuilderFrame, 65, 20, "|c" .. row.color .. row.class .. "|r")
        cBtn:SetPoint("TOPLEFT", 15, startY)

        local currentX = 85
        for _, specName in ipairs(row.specs) do
            local tBtn = CreateSilverButton(GGRaidBuilderFrame, 60, 20, specName)
            tBtn:SetPoint("TOPLEFT", currentX, startY)

            local btn = CreateFrame("Button", nil, GGRaidBuilderFrame, "UIPanelButtonTemplate")
            btn:SetSize(22, 18)
            btn:SetPoint("TOPLEFT", currentX + 63, startY - 1)
            btn:SetText("0")
            btn.count = 0

            table.insert(countButtons, btn)

            btn:SetScript("OnClick", function(self)
                self.count = self.count + 1
                if self.count > 2 then self.count = 0 end
                self:SetText(tostring(self.count))
                neededTalents[specName] = (self.count > 0 and self.count or nil)
                GenerateLFMMessage()
                NotifyMessageChange()
            end)

            currentX = currentX + 92
        end
        startY = startY - 23
    end

    local rolesY = -342
    local needLabel = GGRaidBuilderFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    needLabel:SetPoint("TOPLEFT", 15, rolesY)
    needLabel:SetText("Need")

    local roleKeys = { "Tanks", "MDPS", "RDPS", "Healers" }
    local rx = 65
    for _, rName in ipairs(roleKeys) do
        local chk = CreateFrame("CheckButton", nil, GGRaidBuilderFrame, "UICheckButtonTemplate")
        chk:SetPoint("TOPLEFT", rx, rolesY + 4)
        chk:SetSize(24, 24)
        chk:SetScript("OnClick", function(self)
            needRoles[rName] = self:GetChecked() and true or false
            GenerateLFMMessage()
            NotifyMessageChange()
        end)

        local lbl = GGRaidBuilderFrame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
        lbl:SetPoint("LEFT", chk, "RIGHT", 2, 0)
        lbl:SetText(rName)

        rx = rx + 95
    end

    local bottomY = -378

    local cMsgLabel = GGRaidBuilderFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    cMsgLabel:SetPoint("TOPLEFT", 15, bottomY)
    cMsgLabel:SetText("Custom MSG:")

    local cMsgBox = CreateRectEditBox(GGRaidBuilderFrame, 160, 20)
    cMsgBox:SetPoint("TOPLEFT", 15, bottomY - 16)
    cMsgBox:SetScript("OnTextChanged", function(self)
        customMsgText = self:GetText()
        GenerateLFMMessage()
        NotifyMessageChange()
    end)

    local achLabel = GGRaidBuilderFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    achLabel:SetPoint("TOPLEFT", 195, bottomY)
    achLabel:SetText("Req Ach:")

    local yesBtn = CreateFrame("Button", nil, GGRaidBuilderFrame, "UIPanelButtonTemplate")
    yesBtn:SetSize(35, 22)
    yesBtn:SetPoint("TOPLEFT", 195, bottomY - 16)
    yesBtn:SetText("Yes")
    yesBtn:SetScript("OnClick", function()
        achRequired = "Yes"
        GenerateLFMMessage()
        NotifyMessageChange()
    end)

    local noBtn = CreateFrame("Button", nil, GGRaidBuilderFrame, "UIPanelButtonTemplate")
    noBtn:SetSize(35, 22)
    noBtn:SetPoint("TOPLEFT", 232, bottomY - 16)
    noBtn:SetText("No")
    noBtn:SetScript("OnClick", function()
        achRequired = "No"
        GenerateLFMMessage()
        NotifyMessageChange()
    end)

    local gsLabel = GGRaidBuilderFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    gsLabel:SetPoint("TOPLEFT", 280, bottomY)
    gsLabel:SetText("Min GS:")

    local gsBox = CreateRectEditBox(GGRaidBuilderFrame, 65, 20)
    gsBox:SetPoint("TOPLEFT", 280, bottomY - 16)
    gsBox:SetScript("OnTextChanged", function(self)
        minGsText = self:GetText()
        GenerateLFMMessage()
        NotifyMessageChange()
    end)

    local resLabel = GGRaidBuilderFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    resLabel:SetPoint("TOPLEFT", 360, bottomY)
    resLabel:SetText("Reserved:")

    local resBox = CreateRectEditBox(GGRaidBuilderFrame, 275, 20)
    resBox:SetPoint("TOPLEFT", 360, bottomY - 16)
    resBox:SetScript("OnTextChanged", function(self)
        reservedText = self:GetText()
        GenerateLFMMessage()
        NotifyMessageChange()
    end)

    local achNotice = GGRaidBuilderFrame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    achNotice:SetPoint("TOPLEFT", 15, bottomY - 45)
    achNotice:SetText("Tip: Put achievement inside macro named 'GGRaidAch'")

    local pureLabel = GGRaidBuilderFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    pureLabel:SetPoint("TOPLEFT", 15, bottomY - 75)
    pureLabel:SetText("|cff00FF00Pure Custom Spam (Overrides LFM Builder when enabled):|r")

    local pureBox = CreateRectEditBox(GGRaidBuilderFrame, 400, 20)
    pureBox:SetPoint("TOPLEFT", 15, bottomY - 95)
    pureBox:SetScript("OnTextChanged", function(self)
        pureCustomText = self:GetText()
        NotifyMessageChange()
    end)

    local pureToggleBtn = CreateFrame("Button", nil, GGRaidBuilderFrame, "UIPanelButtonTemplate")
    pureToggleBtn:SetSize(150, 25)
    pureToggleBtn:SetPoint("TOPLEFT", 425, bottomY - 95)
    pureToggleBtn:SetText("Mode: LFM Builder")
    pureToggleBtn:SetScript("OnClick", function(self)
        pureCustomMode = not pureCustomMode
        if pureCustomMode then
            self:SetText("|cff00FF00Mode: Pure Custom|r")
            printMsg("Switched to Pure Custom Spam Mode!")
        else
            self:SetText("Mode: LFM Builder")
            printMsg("Switched back to LFM Builder Mode!")
        end
        NotifyMessageChange()
    end)

    local clearBtn = CreateFrame("Button", nil, GGRaidBuilderFrame, "UIPanelButtonTemplate")
    clearBtn:SetSize(100, 25)
    clearBtn:SetPoint("BOTTOMLEFT", 15, 12)
    clearBtn:SetText("Clear All")
    clearBtn:SetScript("OnClick", function()
        neededTalents = {}
        for _, btn in ipairs(countButtons) do
            btn.count = 0
            btn:SetText("0")
        end
        customMsgText = ""
        cMsgBox:SetText("")
        minGsText = ""
        gsBox:SetText("")
        reservedText = ""
        resBox:SetText("")
        achievementLink = ""
        achRequired = "No"
        pureCustomText = ""
        pureBox:SetText("")
        pureCustomMode = false
        pureToggleBtn:SetText("Mode: LFM Builder")
        for _, rName in ipairs(roleKeys) do
            needRoles[rName] = false
        end
        GenerateLFMMessage()
        NotifyMessageChange()
    end)
end

local timerFrame = CreateFrame("Frame", "GGRaidTimerFrame", UIParent)
timerFrame:SetSize(260, 160)
timerFrame:SetPoint("CENTER")
timerFrame:SetBackdrop({
    bgFile = "Interface/DialogFrame/UI-DialogBox-Background",
    edgeFile = "Interface/DialogFrame/UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 16,
    insets = { left = 5, right = 5, top = 5, bottom = 5 }
})
timerFrame:Hide()
timerFrame:EnableMouse(true)
timerFrame:SetMovable(true)
timerFrame:SetScript("OnMouseDown", function(self, button) if button == "LeftButton" then self:StartMoving() end end)
timerFrame:SetScript("OnMouseUp", function(self) self:StopMovingOrSizing() end)

local tTitle = timerFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
tTitle:SetPoint("TOP", 0, -12)
tTitle:SetText("Modify Interval Timers")

local yLabel = timerFrame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
yLabel:SetPoint("TOPLEFT", 20, -45)
yLabel:SetText("Yell Interval (sec):")

local yBox = CreateRectEditBox(timerFrame, 60, 22)
yBox:SetPoint("TOPLEFT", 160, -42)
yBox:SetText(tostring(yellInterval))

local cLabel = timerFrame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
cLabel:SetPoint("TOPLEFT", 20, -75)
cLabel:SetText("Channel Interval (sec):")

local cBox = CreateRectEditBox(timerFrame, 60, 22)
cBox:SetPoint("TOPLEFT", 160, -72)
cBox:SetText(tostring(chanInterval))

local saveBtn = CreateFrame("Button", nil, timerFrame, "UIPanelButtonTemplate")
saveBtn:SetSize(80, 22)
saveBtn:SetPoint("BOTTOMLEFT", 20, 15)
saveBtn:SetText("Save")
saveBtn:SetScript("OnClick", function()
    local yVal = tonumber(yBox:GetText())
    local cVal = tonumber(cBox:GetText())
    if yVal and yVal > 0 then yellInterval = yVal end
    if cVal and cVal > 0 then chanInterval = cVal end
    printMsg("Timers updated: Yell=" .. yellInterval .. "s | Channel=" .. chanInterval .. "s")
    timerFrame:Hide()
end)

local tCloseBtn = CreateFrame("Button", nil, timerFrame, "UIPanelButtonTemplate")
tCloseBtn:SetSize(80, 22)
tCloseBtn:SetPoint("BOTTOMRIGHT", -20, 15)
tCloseBtn:SetText("Close")
tCloseBtn:SetScript("OnClick", function() timerFrame:Hide() end)


local function HandleCommand(msg)
    local cmd, rest = msg:match("^(%S*)%s*(.-)$")
    cmd = cmd and cmd:lower() or ""

    if cmd == "startyell" then StartYelling()
    elseif cmd == "stopyell" then StopYelling()
    elseif cmd == "startchan" then StartChanneling()
    elseif cmd == "stopchan" then StopChanneling()
    elseif cmd == "ach" then
        if ReadAchievementFromMacro() then
            printMsg("Achievement successfully loaded from macro 'GGRaidAch': " .. achievementLink)
            GenerateLFMMessage()
        else
            printMsg("Error: Macro named 'GGRaidAch' not found or doesn't contain an achievement link!")
        end
    elseif cmd == "channel" then
        if rest:lower() == "global" or rest == "" then
            JoinChannelByName("Global")
            chanName = "Global"
            printMsg("Joined and set channel to: Global")
        else
            chanName = rest
            local id = GetJoinedChannelID(rest)
            if id then chanID = id end
            printMsg("Channel set to: " .. rest)
        end
    elseif cmd == "help" then
        printMsg("--- GGRaid Help & Commands ---")
        printMsg("/ggraidui - Toggle Main UI")
        printMsg("/ggraid startyell / stopyell - Start/Stop Yelling")
        printMsg("/ggraid startchan / stopchan - Start/Stop Channel")
        printMsg("/ggraid channel <name> - Set Channel")
        printMsg("/ggraid ach - Read achievement from 'GGRaidAch' macro")
    elseif cmd == "msg" then
        local activeMsg = pureCustomMode and pureCustomText or yellMessage
        printMsg("Status: Yell(" .. (isYelling and "ON" or "OFF") .. ") | Mode: " .. (pureCustomMode and "Pure Custom" or "LFM Builder") .. " | Msg: " .. activeMsg)
    else
        printMsg("Commands: /ggraid startyell, /ggraid ach, /ggraid channel Global, /ggraid help")
    end
end

SLASH_GGRAID1 = "/ggraid"
SlashCmdList["GGRAID"] = HandleCommand

local function SetupUI()
    if GGRaidButtonStartYell then GGRaidButtonStartYell:SetScript("OnClick", StartYelling) end
    if GGRaidButtonStopYell then GGRaidButtonStopYell:SetScript("OnClick", StopYelling) end
    if GGRaidButtonStartChan then GGRaidButtonStartChan:SetScript("OnClick", StartChanneling) end
    if GGRaidButtonStopChan then GGRaidButtonStopChan:SetScript("OnClick", StartChanneling) end
    if GGRaidButtonBuilder then
        GGRaidButtonBuilder:SetScript("OnClick", function()
            CreateBuilderUIElements()
            if GGRaidBuilderFrame:IsShown() then
                GGRaidBuilderFrame:Hide()
            else
                GGRaidBuilderFrame:Show()
            end
        end)
    end
    if GGRaidButtonHelp then
        GGRaidButtonHelp:SetScript("OnClick", function() HandleCommand("help") end)
    end
    if GGRaidButtonTimer then
        GGRaidButtonTimer:SetScript("OnClick", function()
            if timerFrame:IsShown() then
                timerFrame:Hide()
            else
                timerFrame:Show()
            end
        end)
    end
    if GGRaidButtonClose then GGRaidButtonClose:SetScript("OnClick", function() GGRaidFrame:Hide() end) end
    if GGRaidButtonCurrentMsg then GGRaidButtonCurrentMsg:SetScript("OnClick", function() HandleCommand("msg") end) end
    if GGRaidButtonJoinGlobal then
        GGRaidButtonJoinGlobal:SetScript("OnClick", function()
            JoinChannelByName("Global")
            chanName = "Global"
            local id = GetJoinedChannelID("Global")
            if id then chanID = id end
            printMsg("Joined and set channel to: Global")
        end)
    end
    
    GenerateLFMMessage()
end

frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function(self, event, addonName)
    if addonName == "GGRaid" then
        SetupUI()
    end
end)

SLASH_GGRAIDUI1 = "/ggraidui"
SlashCmdList["GGRAIDUI"] = function()
    if GGRaidFrame:IsShown() then
        GGRaidFrame:Hide()
    else
        GGRaidFrame:Show()
    end
end